#include <stdio.h>
#include "utils.h"

int main(){
    
    // Update these values accordingly
    char* received_msg = NULL;
    int received_msg_size = 0;

    // DO NOT MODIFY THIS LINE
    printf("Accuracy (%%): %f\n", check_accuracy(received_msg, received_msg_size)*100);
}