# CS773 Assignment 1

Refer [this](https://docs.google.com/document/d/1a77P4xrjjIW19FLUkyICbp5-0GycmheJxvPIxOFUmTA/edit?usp=sharing) link to understand the problem statement
